# 3D Science World

A mobile-friendly bilingual (Hindi + English) starter website.

## Run locally
Open `index.html` in a modern browser with an internet connection. Three.js and OrbitControls load from jsDelivr CDN.

## Free hosting with GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a new public repository named `3d-science-world`.
3. Upload `index.html` to the repository root.
4. Open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
6. Wait for the published URL shown in the Pages section.

## Important
This is a first working prototype. It includes sample categories and illustrative 3D models built from simple 3D geometry. These are educational representations, not scientifically exact models or photorealistic scans. More catalogue entries and detailed GLB/GLTF models can be added in later versions.
